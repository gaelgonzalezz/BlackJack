package entidades;

public enum Palo {
    PICAS, CORAZONES, TREBOL, DIAMANTE;
}
