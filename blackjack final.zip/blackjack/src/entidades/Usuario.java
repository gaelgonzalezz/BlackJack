package entidades;

public class Usuario extends Jugador{

    public int dineroDisponible;

    public Usuario(int dineroDisponible) {
        this.dineroDisponible = dineroDisponible;
    }


}
